# Validación de DTD — Frecuencias (?, *, +)

Archivos incluidos:
- `pedido.dtd` — DTD con las frecuencias: `+`, `?`, `*` y elementos obligatorios.
- `pedido_valido.xml` — XML **válido** para el DTD.
- `pedido_invalido.xml` — XML **inválido** para el DTD (sin `<producto>` y con `<cliente>` duplicado).
---

Nota: Ambos XML referencian el DTD vía `<!DOCTYPE pedido SYSTEM "pedido.dtd">`,
por lo que el validador lo leerá automáticamente si todos los archivos están en la misma carpeta.
