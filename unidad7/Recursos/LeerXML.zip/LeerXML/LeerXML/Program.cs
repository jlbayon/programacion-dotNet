﻿
//using System;
//using System.Reflection;
using System.Xml;

namespace LeerXML
{

    class Program
    {
        static void Main(string[] args)
        {
            // el path debe ser absoluto o relativo a la ubicación del ejecutable (puede ser una URL)
            string path = @"c:\Users\Nuria López Álvarez\source\repos\LeerXML\LeerXML\Resources\ArchivoXML.xml";

            //UsingXmlReader(path);
            UsingXmlDocument(path);
            //UsingXmlDocumentWithPath(path);

            //ponerlo porque la consola se cierra automáticamente al detenerse la depuración
            Console.ReadKey();
        }

        private static void UsingXmlReader(string path)
        {
            // intento leer el archivo XML
            try
            {
                // creo un objeto XmlReader
                XmlReader xmlReader = XmlReader.Create(path);

                // leo el XML nodo a nodo
                while (xmlReader.Read())
                {
                    // busco los nodos "alumno"
                    if ((xmlReader.NodeType==XmlNodeType.Element) &&  (xmlReader.Name =="alumno"))
                    {
                        // compruebo que el nodo tiene atributos
                        if (xmlReader.HasAttributes)
                            // muestro los atributos "nombre" y "apellidos"
                            Console.WriteLine(xmlReader.GetAttribute("nombre") + " " + xmlReader.GetAttribute("apellidos"));
                    }
                    // busco los nodos "conocimiento"
                    else if ((xmlReader.NodeType == XmlNodeType.Element) && (xmlReader.Name == "conocimiento"))
                    {
                        // compruebo que el nodo tiene atributos
                        if (xmlReader.HasAttributes)
                            // muestro el atributo "idioma"
                            Console.WriteLine(xmlReader.GetAttribute("idioma"));
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error al leer el archivo XML:\n" + e.Message);
            }
        }

        private static void UsingXmlDocument(string path)
        {
            // creo un objeto XmlDocument
            XmlDocument xmlDoc = new XmlDocument();

            // intento cargar el archivo XML
            try
            {
                // cargo el XML en memoria
                xmlDoc.Load(path);

                /*1*/
                // creo una lista con todos los nodos hijos del nodo raiz
                //XmlNodeList nodeList = xmlDoc.DocumentElement.ChildNodes;
                //ChildNodes devuelve una lista de nodos hijos directos del nodo raiz

                /*2*/
                // creo una lista con todos los nodos hijos del primer nodo hijo del nodo raiz
                XmlNodeList nodeList = xmlDoc.DocumentElement.ChildNodes[0].ChildNodes;
                //ChildNodes[0] es el primer nodo hijo del nodo raiz, osea: <alumno> 
                //ChildNodes[0].ChildNodes es la lista de nodos hijos del primer nodo hijo del nodo raiz, osea: <conocimiento>

                // recorro la lista de nodos hijos
                foreach (XmlNode xmlNode in nodeList)
                {
                    Console.WriteLine(xmlNode.Attributes["nombre"].Value + " " + xmlNode.Attributes["apellidos"].Value );
                    //FistChild es lo mismo que ChildNodes[0] y también que LastChild en este caso
                    foreach (XmlNode xmlNodeItem in xmlNode.FirstChild.ChildNodes)
                    {
                        //Console.WriteLine(xmlNodeItem.Attributes["idioma"]);
                        Console.WriteLine(xmlNodeItem.Attributes["idioma"].Value);

                        
                        Console.WriteLine("Inner Text: " + xmlNodeItem.InnerText);
                        Console.WriteLine("Inner Xml: " + xmlNodeItem.InnerXml);
                        Console.WriteLine("Outer Xml: " + xmlNodeItem.OuterXml);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error al leer el archivo XML:\n" + e.Message);
            }
        }

        private static void UsingXmlDocumentWithPath(string path)
        {
            // creo un objeto XmlDocument
            XmlDocument xmlDoc = new XmlDocument();

            try
            {
                // cargo el XML en memoria (entero)
                xmlDoc.Load(path);
                XmlNodeList itemNodes = xmlDoc.SelectNodes("//Aula//alumnos//alumno");
                // recorro la lista de nodos hijos
                foreach (XmlNode itemNode in itemNodes)
                {
                    Console.WriteLine(itemNode.Attributes["nombre"].Value + " " + itemNode.Attributes["apellidos"].Value);

                    foreach(XmlNode item in itemNode.SelectSingleNode("conocimientos"))
                    {
                        Console.WriteLine(item.Attributes["idioma"].Value);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error al leer el archivo XML:\n" + e.Message);
            }
        }

    }
}